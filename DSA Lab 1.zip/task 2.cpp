#include <stdio.h>

int main() {
    int arr[] = {10, 20, 30};
    int index, value, i;

    printf("Original array:\n");
    for (i = 0; i < 3; i++) {
        printf("%d ", arr[i]);
    }

    printf("\nEnter index to update: ");
    scanf("%d", &index);

    printf("Enter new value: ");
    scanf("%d", &value);

    if (index >= 0 && index < 3) {
        arr[index] = value;
    } else {
        printf("Invalid index\n");
    }

    printf("Updated array:\n");
    for (i = 0; i < 3; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
