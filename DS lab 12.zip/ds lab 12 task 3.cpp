#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int key) {
    if(size == 0)
        return -1;

    if(arr[size - 1] == key)
        return size - 1;

    return linearSearch(arr, size - 1, key);
}

int main() {
    int arr[5] = {5, 10, 15, 20, 25};
    int key = 15;

    int result = linearSearch(arr, 5, key);

    if(result != -1)
        cout << "Found at index: " << result;
    else
        cout << "Not found";

    return 0;
}