#include <iostream>
using namespace std;

int main() {
    int tickets[10] = {13579, 26791, 26792, 33445, 55555,
                       62483, 77777, 79422, 85647, 93121};

    int userNum;
    bool found = false;

    cout << "Enter your 5-digit ticket number: ";
    cin >> userNum;

    for(int i = 0; i < 10; i++) {
        if(tickets[i] == userNum) {
            found = true;
            break;
        }
    }

    if(found)
        cout << "Congratulations! You are a WINNER ??";
    else
        cout << "Invalid ticket number ?";

    return 0;
}