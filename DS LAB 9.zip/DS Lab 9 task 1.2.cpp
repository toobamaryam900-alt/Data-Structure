class Node {
public:
    Applicant data;
    Node* next;
    Node* prev;

    Node(Applicant a) {
        data = a;
        next = NULL;
        prev = NULL;
    }
};