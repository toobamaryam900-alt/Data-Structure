class QueueDLL {
private:
    Node* front;
    Node* rear;

public:
    QueueDLL() {
        front = rear = NULL;
    }

    
    void enqueue(Applicant a) {
        Node* newNode = new Node(a);

        if (rear == NULL) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
    }

    
    void dequeue() {
        if (front == NULL) {
            cout << "Queue is empty\n";
            return;
        }

        Node* temp = front;
        front = front->next;

        if (front != NULL)
            front->prev = NULL;
        else
            rear = NULL;

        delete temp;
    }

    
    void removeSecond() {
        if (front == NULL || front->next == NULL) {
            cout << "Less than 2 applicants\n";
            return;
        }

        Node* second = front->next;

        front->next = second->next;

        if (second->next != NULL)
            second->next->prev = front;
        else
            rear = front;

        delete second;
    }

    
    void display() {
        Node* temp = front;
        while (temp != NULL) {
            cout << "ID: " << temp->data.applicant_id
                 << " | Height: " << temp->data.height
                 << " | Weight: " << temp->data.weight
                 << " | Eyesight: " << temp->data.eyesight
                 << " | Status: " << temp->data.status << endl;

            temp = temp->next;
        }
        cout << "----------------------\n";
    }
};