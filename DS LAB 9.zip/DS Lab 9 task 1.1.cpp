class Applicant {
public:
    int applicant_id;
    double height;
    double weight;
    double eyesight;
    string status;

    Applicant() {}

    Applicant(int id, double h, double w, double eye, string s) {
        applicant_id = id;
        height = h;
        weight = w;
        eyesight = eye;
        status = s;
    }
};