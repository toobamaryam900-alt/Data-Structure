class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    void Enter_garage(int id) {
        Node* newNode = new Node(id);
        newNode->next = top;
        top = newNode;
    }

    void Exit_garage(int id) {
        if (top == NULL) {
            cout << "Garage is empty\n";
            return;
        }

        if (top->truck_id != id) {
            cout << "Truck is not near garage door\n";
            return;
        }

        Node* temp = top;
        top = top->next;
        delete temp;

        cout << "Truck " << id << " exited\n";
    }

    void show() {
        Node* temp = top;
        while (temp != NULL) {
            cout << temp->truck_id << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};