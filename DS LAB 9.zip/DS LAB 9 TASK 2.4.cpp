int main() {
    Queue road;
    Stack garage;

    
    road.On_road(101);
    road.On_road(102);
    road.On_road(103);

    cout << "Road trucks: ";
    road.show();

    
    garage.Enter_garage(road.removeFromRoad());
    garage.Enter_garage(road.removeFromRoad());

    cout << "Garage trucks: ";
    garage.show();

    
    garage.Exit_garage(101);  

    
    garage.Exit_garage(102);

    cout << "Garage after exit: ";
    garage.show();

    cout << "Road trucks: ";
    road.show();

    return 0;
}