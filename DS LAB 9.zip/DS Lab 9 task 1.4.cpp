int main() {
    QueueDLL q;

    
    q.enqueue(Applicant(1, 5.6, 60, 1.2, "Pending"));
    q.enqueue(Applicant(2, 5.8, 65, 1.0, "Pending"));
    q.enqueue(Applicant(3, 5.5, 55, 0.9, "Pending"));
    q.enqueue(Applicant(4, 6.0, 70, 1.5, "Pending"));
    q.enqueue(Applicant(5, 5.7, 68, 1.1, "Pending"));
    q.enqueue(Applicant(6, 5.9, 72, 1.3, "Pending"));
    q.enqueue(Applicant(7, 6.1, 75, 1.0, "Pending"));

    cout << "Initial Queue:\n";
    q.display();
    
    cout << "After removing 2nd applicant (urgency):\n";
    q.removeSecond();
    q.display();

    
    cout << "After first applicant gives test:\n";
    q.dequeue();
    q.display();


    q.enqueue(Applicant(8, 5.8, 66, 1.2, "Pending"));

    cout << "After adding new applicant:\n";
    q.display();

    return 0;
}