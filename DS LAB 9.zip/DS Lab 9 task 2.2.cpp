class Queue {
private:
    Node* front;
    Node* rear;

public:
    Queue() {
        front = rear = NULL;
    }

    void On_road(int id) {
        Node* newNode = new Node(id);

        if (rear == NULL) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    int removeFromRoad() {
        if (front == NULL) return -1;

        Node* temp = front;
        int id = temp->truck_id;
        front = front->next;

        if (front == NULL)
            rear = NULL;

        delete temp;
        return id;
    }

    void show() {
        Node* temp = front;
        while (temp != NULL) {
            cout << temp->truck_id << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    bool isEmpty() {
        return front == NULL;
    }
};