class Node {
public:
    int truck_id;
    Node* next;

    Node(int id) {
        truck_id = id;
        next = NULL;
    }
};