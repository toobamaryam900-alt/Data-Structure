#include <iostream>
using namespace std;

class Node {
public:
    string title;
    float price;
    int edition;
    int pages;
    Node* next;

    Node(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};

class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }
    
    void push(string title, float price, int edition, int pages) {
        Node* newNode = new Node(title, price, edition, pages);
        newNode->next = top;
        top = newNode;
        cout << "Book pushed: " << title << endl;
    }

    
    void pop() {
        if (top == NULL) {
            cout << "Stack is empty\n";
            return;
        }

        Node* temp = top;
        cout << "Book popped: " << top->title << endl;
        top = top->next;
        delete temp;
    }

    
    void peek() {
        if (top == NULL) {
            cout << "Stack is empty\n";
        } else {
            cout << "\nTop Book Details:\n";
            cout << "Title: " << top->title << endl;
            cout << "Price: " << top->price << endl;
            cout << "Edition: " << top->edition << endl;
            cout << "Pages: " << top->pages << endl;
        }
    }

    
    void display() {
        if (top == NULL) {
            cout << "Stack is empty\n";
            return;
        }

        Node* temp = top;
        cout << "\nRemaining Books in Stack:\n";

        while (temp != NULL) {
            cout << "Title: " << temp->title
                 << ", Price: " << temp->price
                 << ", Edition: " << temp->edition
                 << ", Pages: " << temp->pages << endl;

            temp = temp->next;
        }
    }
};

int main() {
    Stack s;

    
    s.push("C++ Programming", 1200, 3, 500);
    s.push("Data Structures", 950, 2, 420);
    s.push("Algorithms", 1100, 4, 600);
    s.push("Operating Systems", 1000, 5, 550);
    s.push("Computer Networks", 900, 2, 450);

    
    s.peek();

    
    s.pop();
    s.pop();


    s.display();

    return 0;
}