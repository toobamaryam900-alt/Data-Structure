#include <iostream>
using namespace std;

class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
	
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    
    void display() {
        cout << "Serial Number: " << serialNum << endl;
        cout << "Manufacture Year: " << manufactYear << endl;
        cout << "Lot Number: " << lotNum << endl;
    }
};


class Node {
public:
    Inventory part;
    Node* next;
};
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    
    void push(Inventory item) {
        Node* newNode = new Node;
        newNode->part = item;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory.\n";
    }

    
    void pop() {
        if (top == NULL) {
            cout << "Inventory stack is empty.\n";
            return;
        }

        Node* temp = top;
        cout << "\nPart removed from inventory:\n";
        temp->part.display();

        top = top->next;
        delete temp;
    }
    void display() {
        if (top == NULL) {
            cout << "No parts remaining in inventory.\n";
            return;
        }

        Node* temp = top;
        cout << "\nRemaining Parts in Inventory:\n";

        while (temp != NULL) {
            temp->part.display();
            cout << "-----------------\n";
            temp = temp->next;
        }
    }
};

int main() {
    Stack inventoryStack;
    int choice;

    do {
        cout << "\n1. Add Part to Inventory\n";
        cout << "2. Take Part from Inventory\n";
        cout << "3. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int s, y, l;
            Inventory item;

            cout << "Enter Serial Number: ";
            cin >> s;

            cout << "Enter Manufacturing Year: ";
            cin >> y;

            cout << "Enter Lot Number: ";
            cin >> l;

            item.setData(s, y, l);
            inventoryStack.push(item);
        }

        else if (choice == 2) {
            inventoryStack.pop();
        }

    } while (choice != 3);

    
    inventoryStack.display();

    return 0;
}