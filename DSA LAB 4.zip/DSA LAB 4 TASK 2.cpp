#include <iostream>
#include <string>
using namespace std;


struct Node {
    int userID;
    string name;
    int age;
    string email;
    Node* next;
};

Node* head = NULL;

void createProfile() {
    Node* newNode = new Node();

    cout << "Enter User ID: ";
    cin >> newNode->userID;
    cin.ignore();

    cout << "Enter Name: ";
    getline(cin, newNode->name);

    cout << "Enter Age: ";
    cin >> newNode->age;
    cin.ignore();

    cout << "Enter Email: ";
    getline(cin, newNode->email);

    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
    }

    cout << "Profile Created Successfully!\n";
}


Node* searchProfile(int id) {
    Node* temp = head;
    while (temp != NULL) {
        if (temp->userID == id)
            return temp;
        temp = temp->next;
    }
    return NULL;
}


void updateProfile() {
    int id;
    cout << "Enter User ID to Update: ";
    cin >> id;
    cin.ignore();

    Node* user = searchProfile(id);

    if (user == NULL) {
        cout << "Profile Not Found!\n";
        return;
    }

    cout << "Enter New Name: ";
    getline(cin, user->name);

    cout << "Enter New Age: ";
    cin >> user->age;
    cin.ignore();

    cout << "Enter New Email: ";
    getline(cin, user->email);

    cout << "Profile Updated Successfully!\n";
}


void deleteProfile() {
    if (head == NULL) {
        cout << "No Profiles Available.\n";
        return;
    }

    int id;
    cout << "Enter User ID to Delete: ";
    cin >> id;

    Node* temp = head;
    Node* prev = NULL;

    if (temp != NULL && temp->userID == id) {
        head = temp->next;
        delete temp;
        cout << "Profile Deleted Successfully!\n";
        return;
    }

    while (temp != NULL && temp->userID != id) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Profile Not Found!\n";
        return;
    }

    prev->next = temp->next;
    delete temp;

    cout << "Profile Deleted Successfully!\n";
}


void viewProfiles() {
    if (head == NULL) {
        cout << "No Profiles Available.\n";
        return;
    }

    Node* temp = head;
    cout << "\n--- All User Profiles ---\n";

    while (temp != NULL) {
        cout << "User ID: " << temp->userID << endl;
        cout << "Name: " << temp->name << endl;
        cout << "Age: " << temp->age << endl;
        cout << "Email: " << temp->email << endl;
        cout << "--------------------------\n";
        temp = temp->next;
    }
}


int main() {
    int choice;

    do {
        cout << "\n===== Social Media Profile Management =====\n";
        cout << "1. Create Profile\n";
        cout << "2. Update Profile\n";
        cout << "3. Delete Profile\n";
        cout << "4. Search Profile\n";
        cout << "5. View All Profiles\n";
        cout << "6. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                createProfile();
                break;
            case 2:
                updateProfile();
                break;
            case 3:
                deleteProfile();
                break;
            case 4: {
                int id;
                cout << "Enter User ID to Search: ";
                cin >> id;
                Node* user = searchProfile(id);
                if (user != NULL) {
                    cout << "Profile Found!\n";
                    cout << "Name: " << user->name << endl;
                    cout << "Age: " << user->age << endl;
                    cout << "Email: " << user->email << endl;
                } else {
                    cout << "Profile Not Found!\n";
                }
                break;
            }
            case 5:
                viewProfiles();
                break;
            case 6:
                cout << "Exiting Program...\n";
                break;
            default:
                cout << "Invalid Choice!\n";
        }

    } while (choice != 6);

    return 0;
}