#include <iostream>
#include <string>
using namespace std;


struct Node {
    string brand;
    int units;
    float price;
    Node* next;
};


Node* head = NULL;


void addMobile() {
    Node* newNode = new Node();

    cout << "Enter Brand Name: ";
    cin >> newNode->brand;

    cout << "Enter Units in Stock: ";
    cin >> newNode->units;

    cout << "Enter Price: ";
    cin >> newNode->price;

    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    cout << "Mobile Added Successfully!\n";
}


void deleteMobile() {
    if (head == NULL) {
        cout << "Inventory is empty.\n";
        return;
    }

    string brandName;
    cout << "Enter Brand Name to Delete: ";
    cin >> brandName;

    Node* temp = head;
    Node* prev = NULL;

    
    if (temp != NULL && temp->brand == brandName) {
        head = temp->next;
        delete temp;
        cout << "Mobile Deleted Successfully!\n";
        return;
    }

    
    while (temp != NULL && temp->brand != brandName) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Mobile Not Found.\n";
        return;
    }

    prev->next = temp->next;
    delete temp;
    cout << "Mobile Deleted Successfully!\n";
}


void displayMobiles() {
    if (head == NULL) {
        cout << "Inventory is empty.\n";
        return;
    }

    Node* temp = head;

    cout << "\n--- Mobile Inventory ---\n";
    while (temp != NULL) {
        cout << "Brand: " << temp->brand << endl;
        cout << "Units: " << temp->units << endl;
        cout << "Price: " << temp->price << endl;
        cout << "------------------------\n";
        temp = temp->next;
    }
}

int main() {
    int choice;

    do {
        cout << "\n===== Mobile Store Inventory =====\n";
        cout << "1. Add Mobile\n";
        cout << "2. Delete Mobile\n";
        cout << "3. Display Mobiles\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                addMobile();
                break;
            case 2:
                deleteMobile();
                break;
            case 3:
                displayMobiles();
                break;
            case 4:
                cout << "Exiting Program...\n";
                break;
            default:
                cout << "Invalid Choice.\n";
        }

    } while (choice != 4);

    return 0;
}